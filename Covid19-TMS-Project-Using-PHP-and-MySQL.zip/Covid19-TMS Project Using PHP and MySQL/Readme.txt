How to run the COVID19 Testing Management System Using PHP and MySQL

Download the zip file
Extract the file and copy covid-tms folder
Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
Open PHPMyAdmin (http://localhost/phpmyadmin)
Create a database with name covidtmsdb
Import covidtmsdb.sql file(given inside the zip package in SQL file folder)
Run the script http://localhost/covid-tms

Admin Credential
Username: admin
Password: Test@123